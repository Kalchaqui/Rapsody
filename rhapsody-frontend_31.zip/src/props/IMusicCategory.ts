export interface IMusicCategory {
    type:string;
}