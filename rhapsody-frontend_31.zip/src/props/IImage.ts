export interface IImage {
    url:string;
}