export interface IUser {
    name: string;
    username: string;
    email: string;
    createdAt: string;
    avatarImage: string;
    ethaddress:string;
}