export interface ISocial {
    type:string;
    url: string;
}