export const AppConfig = {
  site_name: 'Starter',
  title: 'R Seed',
  description:
    'Starter code for your Nextjs Boilerplate with tailwind-styled-components',
  locale: 'en',
};
