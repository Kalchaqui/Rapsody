const params = {
    type: 'type',
  }
  export default {
    className: 'MembershipCardModel',
    params
  }
  