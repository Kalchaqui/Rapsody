const params = {
    name: 'name',
  }
  
  export default {
    className: 'MusicCategory',
    params
  }  