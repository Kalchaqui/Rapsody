const params = {
    interests: 'interests',
  }
  
  export default {
    className: '_User',
    params
  }
  