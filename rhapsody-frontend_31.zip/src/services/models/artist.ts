const params = {
    name: 'name',
    username: "username",
    email:'email',
    avatarImage:"avatarImage",
  }
  
  export default {
    className: 'Artist',
    params
  }
  