const params = {
  isActive: "isActive",
  description: "description",
  startDate: "startDate",
  releaseDate: "releaseDate",
  coverImage: "coverImage",
  artistId: "artistId"
};

export default {
  className: "Project",
  params,
};
