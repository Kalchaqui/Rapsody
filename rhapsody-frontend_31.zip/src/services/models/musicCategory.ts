const params = {
    type: 'type',
  }
  
  export default {
    className: 'MusicCategory',
    params
  }
  