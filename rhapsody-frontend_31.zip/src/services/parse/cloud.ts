export default {
  api: {
    addEmailOnGlobaltWaitList:{
      name: "addEmailOnGlobaltWaitList",
    },
    addUserOnProjectWaitList: {
      name: "addUserOnProjectWaitList",
    },
    getAuthLink:{
      name:'getAuthLink'
    },
    deleteAccount:{
      name:'deleteAccount'
    },
    updateAvatarImage:{
      name:'updateAvatarImage'
    },
    createWallet:{
      name:'createWallet'
    }
  },
};
